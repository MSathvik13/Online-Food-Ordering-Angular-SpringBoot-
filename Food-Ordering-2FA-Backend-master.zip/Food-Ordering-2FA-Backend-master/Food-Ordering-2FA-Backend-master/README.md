# Food-Ordering-2FA-Backend
working of email confirmation to register a new user
