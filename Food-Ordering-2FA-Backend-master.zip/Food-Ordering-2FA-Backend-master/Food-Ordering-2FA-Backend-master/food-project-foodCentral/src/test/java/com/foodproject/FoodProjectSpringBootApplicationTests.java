package com.foodproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodProjectSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
